This installation requires the python distribution package: setuptools. If
setuptools is not installed, you may download it from pypi:
https://pypi.python.org/pypi/setuptools 


To install MyNCList:

`sudo MyNCList-install.sh`

If you do not have access to a MySQL database, add the `--mysql` flag to the
installation command to install MySQL on your local linux machine and create
a database "nclist."

